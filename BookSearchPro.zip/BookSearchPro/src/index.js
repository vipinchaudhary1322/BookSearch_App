import React, { useState } from "react";
import ReactDOM from "react-dom";
import axios from "axios";
import "./styles.css";

const App = () => {
  const [search, setSearch] = useState("");
  const [books, setBooks] = useState({ items: [] });
  const onInputChange = e => {
    setSearch(e.target.value);
  };

  let API_URL = `https://www.googleapis.com/books/v1/volumes`;

  const fetchBooks = async () => {
    const result = await axios.get(`${API_URL}?q=${search}`);
    setBooks(result.data);
  };

  const onSubmitHandler = e => {
    e.preventDefault();
    fetchBooks();
  };

  const bookAuthors = authors => {
    if (authors.length <= 2) {
      authors = authors.join(" and ");
    } else if (authors.length > 2) {
      let lastAuthor = " and " + authors.slice(-1);
      authors.pop();
      authors = authors.join(", ");
      authors += lastAuthor;
    }
    return authors;
  };

  return (
    <section className="main">
      <form onSubmit={onSubmitHandler}>
        <label>
          <span className="head">Search for books</span>
          <input
            type="search"
            placeholder="Enter Your Book Name"
            value={search}
            onChange={onInputChange}
          />
          <button type="submit">Search</button>
        </label>
      </form>
      <div className="books" >
        {books.items.map((book, index) => {
          return (
            <li key={index}>
              <div className="card" id="zoom">
                <img
                  alt={`${book.volumeInfo.title} book`}
                  src={`http://books.google.com/books/content?id=${
                    book.id
                  }&printsec=frontcover&img=1&zoom=1&source=gbs_api`}
                />
                <div>
                  <h3>{book.volumeInfo.title}</h3>
                  <p>{bookAuthors(book.volumeInfo.authors)}</p>
                  <p>{book.volumeInfo.publishedDate}</p>
                </div>
              </div>
      
            </li>
          );
        })}
      </div>
    </section>
  );
};

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
